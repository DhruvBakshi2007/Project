pav bhaji

1. First take the chopped veggies, mainly: cauliflower, potatoes, carrots, peas and french beans. You can either rinse or chop them or rinse after chopping them.

veggies to make kada pav bhaji recipe



2. Keep the veggies in a pan or pressure cooker. Now add water to the veggies just about covering them.

making kada pav bhaji recipe
4. Sprinkle 1 teaspoon of salt or as required.

salt for kada pav bhaji recipe



5. Pressure cook or boil the veggies till they are done. Do not overcook the veggies.

veggies for preparing kada pav bhaji recipe
6. In the picture below, the veggies are cooked. Strain the veggies and keep the broth or stock.

making khada pav bhaji recipe



7. In the meantime, when the vegetables are cooking, chop the onions, green chillies, ginger, tomatoes and capsicum. Half of the ginger is to be chopped and the remaining half to be made into a paste.

preparing khada pav bhaji recipe
8. In the mortar and pestle crush the remaining half of the ginger and 5 to 6 medium sized garlic cloves. You can keep it coarsely crushed or make a fine paste. You could also use ready ginger-garlic paste.

making kada pav bhaji recipe



9. In a kadai or a big tava heat around 2 tablespoons butter or oil.

butter for kada pav bhaji recipe
10. Add the onions and saute till they become translucent.

onions for kada pav bhaji recipe



11. Then add the chopped tomatoes.

tomatoes for making kada pav bhaji recipe
12. Also add the chopped ginger, green chilies and capsicum.

making khada pav bhaji recipe



13. Saute for 7 to 8 minutes stirring in between till the tomatoes soften and become mushy.

making kada pav bhaji recipe
14. Now add the red chili powder and turmeric powder.

spices for kada pav bhaji recipe



15. Mix the spice powders and saute for 1 to 2 minutes.

spices for kada pav bhaji recipe
16. Add the ginger-garlic paste or crushed ginger-garlic.

preparing kada pav bhaji recipe
17. Mix it very well and saute for 2 minutes more.




making khada pav bhaji recipe
18. Add 1 to 2 tablespoon butter to the masala.

butter to make khada pav bhaji recipe
19. Add the boiled vegetables.

preparing khada pav bhaji recipe



20. Stir and mix well.

making kada pav bhaji recipe
21. Add the pav bhaji masala.

making kada pav bhaji recipe


22. Add about 1 or 1.5 cups of stock or water or both stock+water.

making kada pav bhaji recipe
23. Gently mix the entire mixture.

making khada pav bhaji recipe


24. Simmer for 10 to 12 minutes on a low flame till the gravy thickens a bit.

kada pav bhaji recipe
25. Keep checking the bhaji in between.

kada pav bhaji recipe


26. Now, add the garam masala powder and gently mix it with the rest of the bhaji.

kada pav bhaji recipe
27. Lastly, add chopped coriander leaves. Check the taste and adjust spices and salt as per your taste. The bhaji Is ready now.

kada pav bhaji recipe


28. Slice the pavs and fry them on the tava or griddle with some butter.

pav for kada pav bhaji recipe
Serve the Khada Pav bhaji topped with butter and with warm pavs, chopped onion and chopped lemon.

kada pav bhaji recipe


More Mumbai street food recipes

Dahi puri
Misal pav
Bhel puri
Sev puri
Pani puri.
If you made this recipe, please be sure to rate it in the recipe card below. If you'd like more delicious Indian vegetarian recipes delivered straight to your inbox, Sign Up for my email newsletter. You can also follow me on Instagram, Facebook, Youtube, Pinterest or Twitter for more vegetarian inspiration.



khada pav bhaji recipe
Khada Pav Bhaji (With Vegetable Chunks)
5 from 1 vote
Dassana AmitBy Dassana Amit

Khada pav bhaji is a variation of pav bhaji where the chopped and cooked vegetables are kept intact, chunky and not mashed. A different and unique street food from Mumbai.
 Save
 Pin
 Print
Prep Time
15 mins
Cook Time
45 mins
Total Time
1 hr


Cuisine
Indian Street Food, Mumbai Street Food
Course:
Snacks
Servings
3
 bowls 
Units




Instructions
Preparation
First take the chopped veggies, mainly: cauliflower, potatoes, carrots, peas and beans. Keep these in a pan or cooker. Now add water to the veggies just about covering them.
Pressure cook or boil the veggies till they are done. Do not over cook the veggies. In the picture below, the veggies are cooked. Strain the veggies and keep the broth or stock.
In the meantime, when the vegetables are cooking, chop the onions, green chillies, ginger, tomatoes and capsicum.
In the mortar and pestle crush the remaining half ginger and garlic cloves. You can keep it coarsely crushed or make a fine paste. You could also use ready ginger-garlic paste.
Making Khada Pav Bhaji
In a kadai or a big tava heat up around 2 tablespoon oil or butter. Add the onions and fry till they become transparent.
Add the chopped tomatoes, ginger, green chillies and capsicum. Saute for 7 to 8 minutes stirring in between.
Now add the red chili powder and turmeric powder. Mix the powders and saute for 1 to 2 minutes.
Add in the ginger garlic paste or crushed ginger garlic. Mix it and saute for 2 minutes more.
Add 1 to 2 tablespoon butter to the masala. 
Add the boiled vegetables and the pav bhaji masala.
Add about 1 or 1.5 cups of broth or water or both broth+water. Gently mix the entire mixture.
Simmer for 10 to 12 minutes on a low flame. Keep checking the bhaji in between.
Now, add the garam masala powder and gently mix it with the rest of the bhaji.
Lastly, add chopped coriander leaves.
Your khada pav bhaji is ready now. Slice the pavs and fry them on the tava or griddle with some butter. Serve the bhaji topped with butter with the warm pavs, chopped onion and chopped lemon.


Like our videos? Then do follow and subscribe to us on youtube to get the latest Recipe Video updates.

Tried this recipe?
If you have made the recipe and liked it then do share the recipe link on facebook, twitter & pinterest. For instagram mention @dassanasvegrecipes and tag #dassanasvegrecipes!
All our content & photos are copyright protected. Please do not copy. As a blogger, if you you want to adapt this recipe or make a youtube video, then please write the recipe in your own words and give a clickable link back to the recipe on this url.

Like this Recipe?
Pin it Now to Remember it Later

Pin Recipe Now

Share This Recipe:

Shares
563
Dassana Amit
Meet Dassana

Welcome to Dassana's Veg Recipes. I share vegetarian recipes from India & around the World. Having been cooking for decades and with a professional background in cooking & baking, I help you to make your cooking journey easier with my tried and tested recipes showcased with step by step photos & plenty of tips & suggestions.

Read More
Get My Secrets to Great Indian Food
Sign up for my FREE Beginners Guide to Delicious Indian Cooking
First Name *
Your First Name
Email *
Your Email
Sign Up
Comments are closed.

12 Comments
Gustavo Woltmann
Jan 01, 2017 at 10:26 pm
This seems very delicious… Definitely i need to try it asap 🙂5 stars

Dassana Amit
Jan 02, 2017 at 5:18 pm
thanks gustavo. do try the recipe.

SHRADDHA
Sep 28, 2011 at 9:36 pm
dish looking nice i will try it thankx

See More Comments

Search Recipes

Search for
Search…

Dassana Amit
Meet Dassana

Hi, I am Dassana. Running the kitchen for decades, I share tried and tested Vegetarian recipes on my food blog since 2009, with a step-by-step photo guide & plenty of tips so that your cooking journey is easier. I also have a professional background in cooking & baking.

Read More
Follow Us

Facebook YouTube Pinterest Twitter Instagram




Popular Recipes

paneer butter masala served in a blue rimmed white pan, garnished with cream and cilantro
Paneer Recipes

Paneer Butter Masala

dal makhani served in a copper bucket and garnished with three cilantro sprigs
Dal (Lentils) & Legumes

Dal Makhani

chana masala recipe, chole recipe, how to make chana masala
Chickpeas

Chana Masala | Punjabi Chole Masala (Stovetop & Instant Pot)

idli recipe, how to make idli, idli batter recipe
Vegan Recipes

Idli Recipe | How To Make Idli Batter

samosa arranged in a line on a cream tray with chutneys in small bowls and fried green chillies on the tray
Snacks Recipes

Samosa Recipe

rajma masala garnished with a few kasuri methi and served in a white bowl on a brown wooden board and a plate of rice and rajma curry with a spoon kept on left top side of the board
Dal (Lentils) & Legumes

Rajma Recipe (Kidney Bean Curry)

mumbai pav bhaji recipe
Street Food Recipes

Pav Bhaji – Mumbai Street Style Recipe

dosa recipe, dosa batter recipe, how to make dosa recipe
Vegan Recipes

Plain Dosa Recipe And Dosa Batter (Sada Dosa)

Popular Baking Recipes

eggless banana bread
Vegan Recipes

Banana Bread (Eggless And Vegan)

eggless chocolate chip cookies stacked with some halved cookies on a white plate
Cookies

Eggless Chocolate Chip Cookies

Whole round Pizza on a wooden pizza plate with a cut triangular slice on left top side
Bread

Pizza Recipe | Veg Pizza

A triangular slice of eggless chocolate cake on a white plate
Cakes (Eggless)

Eggless Chocolate Cake

