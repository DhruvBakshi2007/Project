Ingredients
▢½ to ¾ cup cauliflower florets
▢2 to 3 small carrots - cubed
▢¼ cup french beans - chopped
▢2 medium potatoes - cubed
▢⅓ cup green peas - fresh or frozen
▢1 medium onion - finely chopped
▢2 medium tomatoes - finely chopped
▢1 green chili - finely chopped
▢1 medium sized capsicum, (bell pepper) - finely chopped
▢1 inch ginger - use half of the ginger for making the ginger-garlic paste and half to be chopped
▢5 to 6 medium sized garlic cloves - chopped
▢½ to 1 tablespoon Pav Bhaji Masala
▢¼ teaspoon Garam Masala Powder
▢¼ teaspoon red chili powder
▢¼ teaspoon turmeric powder
▢a few sprigs of coriander leaves, for garnish
▢chopped lemon to be served with pav bhaji
▢2 to 3 tablespoons butter or oil - preferably amul butter
▢salt as required
▢water as required